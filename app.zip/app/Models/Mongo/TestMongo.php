<?php

namespace App\Models\Mongo;

class TestMongo extends BaseMongoModel
{
    protected $collection = 'test_mongo';
}