<script setup>
import { computed } from 'vue'
import { usePage } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'

const page = usePage()

const creator = computed(() => page.props.creator)
</script>

<template>
<AppLayout>

<div class="max-w-4xl mx-auto">

    <div class="bg-white border rounded-lg p-6">

        <!-- NAME -->
        <h1 class="text-2xl font-bold">
            {{ creator.display_name }}
        </h1>

        <!-- LOCATION -->
        <div class="text-gray-500 mb-4">
            {{ creator.location }}
        </div>

        <!-- BIO -->
        <p class="mb-6">
            {{ creator.bio }}
        </p>

        <!-- PLATFORMS -->
        <div class="mb-6">

            <h2 class="font-semibold mb-2">
                Platforms
            </h2>

            <div
                v-for="platform in creator.platforms"
                :key="platform.platform"
                class="border rounded p-3 mb-2">

                <div class="font-medium">
                    {{ platform.platform }}
                </div>

                <div class="text-sm text-gray-600">
                    @{{ platform.username }}
                </div>

                <div class="text-sm">
                    Followers: {{ platform.followers }}
                </div>

                <div class="text-sm">
                    Engagement: {{ platform.engagement }}%
                </div>

            </div>

        </div>

        <!-- PRICING -->
        <div>

            <h2 class="font-semibold mb-2">
                Pricing
            </h2>

            <div>

  

    <div class="grid grid-cols-3 gap-4">

        <div>
            Post: ₹{{ creator.pricing?.post ?? 0 }}
        </div>

        <div>
            Story: ₹{{ creator.pricing?.story ?? 0 }}
        </div>

        <div>
            Reel: ₹{{ creator.pricing?.reel ?? 0 }}
        </div>

    </div>

</div>

        </div>

    </div>

</div>

</AppLayout>
</template>