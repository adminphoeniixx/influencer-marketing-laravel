<script setup>
import { computed } from 'vue'
import { usePage, Link } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'

const page = usePage()

const creators = computed(() => page.props.creators ?? [])
</script>

<template>
<AppLayout>

<div class="max-w-7xl mx-auto">

    <h1 class="text-2xl font-bold mb-6">
        Browse Creators
    </h1>

    <!-- EMPTY -->
    <div v-if="creators.length === 0"
         class="bg-white border rounded p-6 text-center">

        No creators found.

    </div>

    <!-- GRID -->
    <div v-else
         class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        <div v-for="creator in creators"
             :key="creator._id"
             class="bg-white border rounded-lg p-5 hover:shadow transition">

            <div class="text-lg font-semibold">
                {{ creator.display_name }}
            </div>

            <div class="text-sm text-gray-500 mb-2">
                {{ creator.location }}
            </div>

            <div class="text-sm text-gray-700 mb-4">
                {{ creator.bio }}
            </div>

            <div class="text-xs text-gray-500 mb-3">
                Platforms:
                <span
                    v-for="p in creator.platforms"
                    :key="p.platform"
                    class="mr-2"
                >
                    {{ p.platform }}
                </span>
            </div>

            <Link
                :href="`/app/creators/${creator._id}`"
                class="inline-block px-4 py-2 bg-black text-white rounded hover:bg-gray-800"
            >
                View Profile
            </Link>

        </div>

    </div>

</div>

</AppLayout>
</template>